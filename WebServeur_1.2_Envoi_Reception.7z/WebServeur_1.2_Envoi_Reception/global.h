
#include "rl_net.h"                     /* Network definitions                */
#include <stdio.h>
#include <string.h>
#include "rl_net.h"
#include "Board_GLCD.h"
#include "Board_ADC.h"
#include "Board_LED.h"

typedef struct {
	char udp[50];
	char table[50];
	short val[10];
} Noot;
