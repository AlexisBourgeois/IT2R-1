/*---------------------------------------------------
* CAN 2 uniquement en TX 
* + r�ception CAN1 
* avec RTOS et utilisation des fonction CB
* pour test sur 1 carte -> relier CAN1 et CAN2
* 2017-04-02 - XM
---------------------------------------------------*/

#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions

#include "LPC17xx.h"                    // Device header
#include "Driver_CAN.h"                 // ::CMSIS Driver:CAN
#include "Board_GLCD.h"                 // ::Board Support:Graphic LCD
#include "GLCD_Config.h"                // Keil.MCB1700::Board Support:Graphic LCD
#include "stdio.h"
#include "stdlib.h"
#include "cmsis_os.h"

/*----------------------------------------------------------------------------------------*
 * Definition des identifiants du bus CAN pour permettre la communication dans la voiture *
 *----------------------------------------------------------------------------------------*/
#define ID_AU 		0x002		//arret d'urgence
#define ID_USF 		0x027		//Ultrasons avant
#define ID_USM 		0x043		//Ultrasons milieu
#define ID_USB 		0x033		//Ultrasons arri�re
#define ID_LED 		0x065		//Commande de la barre de DEL arri�re
#define ID_PHARE	0x085		//Allumage des phares
#define ID_GPS 		0x0C5		//G�olocalisation GPS
#define ID_LIDAR	0x113		//Analyse de l'environnement

#define FILTRE_CARTE_D	0x001		//Carte arri�re
#define FILTRE_CARTE_S	0x002		//Carte centrale
#define FILTRE_CARTE_L	0x004		//Carte avant

#define DATA_REQUETE 0xB1 //Donn�e que l'on envoie lors d'une requ�te sur bus CAN

extern GLCD_FONT GLCD_Font_6x8;
extern GLCD_FONT GLCD_Font_16x24;

osThreadId id_CANthreadR;
osThreadId id_CANthreadT;
osThreadId id_tache_LIDAR;

osSemaphoreId ID_sema_CAN; // Semaphore pour acc�s bus CAN
osSemaphoreDef (sema_CAN);

//******************Variables globales de l'envoi sur bus CAN******************
uint8_t donnee_envoi_CAN[8];
char longueur_envoi_CAN;
short ID_envoi_CAN;

//******************Variables globales de r�ception sur bus CAN******************
short dist_USF1;
short dist_USF2;
short dist_USF3;

short dist_USB1;
short dist_USB2;
short dist_USB3;

short dist_USM1;
short dist_USM2;

extern   ARM_DRIVER_CAN         Driver_CAN1;

// CAN1 utilis� pour r�ception
void myCAN1_callback(uint32_t obj_idx, uint32_t event)
{
    switch (event)
    {
    case ARM_CAN_EVENT_RECEIVE:
        /*  Message was receive d successfully by the obj_idx object. */
       osSignalSet(id_CANthreadR, 0x01);
        break;
		
		case ARM_CAN_EVENT_SEND_COMPLETE:
        /* 	Message was sent successfully by the obj_idx object.  */
        osSignalSet(id_CANthreadT, 0x01);
        break;
    }
}


// CAN1 utilis� pour r�ception
void InitCan1 (void) {
	Driver_CAN1.Initialize(NULL,myCAN1_callback);
	Driver_CAN1.PowerControl(ARM_POWER_FULL);
	
	Driver_CAN1.SetMode(ARM_CAN_MODE_INITIALIZATION);
	Driver_CAN1.SetBitrate( ARM_CAN_BITRATE_NOMINAL,
													125000,
													ARM_CAN_BIT_PROP_SEG(5U)   |         // Set propagation segment to 5 time quanta
                          ARM_CAN_BIT_PHASE_SEG1(1U) |         // Set phase segment 1 to 1 time quantum (sample point at 87.5% of bit time)
                          ARM_CAN_BIT_PHASE_SEG2(1U) |         // Set phase segment 2 to 1 time quantum (total bit is 8 time quanta long)
                          ARM_CAN_BIT_SJW(1U));                // Resynchronization jump width is same as phase segment 2
                          
	// Mettre ici les filtres ID de r�ception sur objet 0
	//....................................................
	// Filtre objet 0 sur Identifiant FILTRE_CARTE_S
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_USB),
															0) ; 
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_USF),
															0) ; 
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_USM),
															0) ; 
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_AU),
															0) ;
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_LED),
															0) ;
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_PHARE),
															0) ; 
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_GPS),
															0) ; 
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_LIDAR),
															0) ; 	
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(ID_LED),
															0) ; 																	
	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_EXACT_ADD ,
															ARM_CAN_STANDARD_ID(0x3FF),
															0) ; 													
//	Driver_CAN1.ObjectSetFilter( 0, ARM_CAN_FILTER_ID_MASKABLE_ADD ,
//														ARM_CAN_STANDARD_ID(0x033),
//														0x000 ) ; 
	
	Driver_CAN1.ObjectConfigure(1,ARM_CAN_OBJ_TX);	
	Driver_CAN1.ObjectConfigure(0,ARM_CAN_OBJ_RX);				// Objet 0 du CAN1 pour r�ception
	
	Driver_CAN1.SetMode(ARM_CAN_MODE_NORMAL);					// fin init
}

// tache envoi toutes les secondes
void CANthreadT(void const *argument)
{
	ARM_CAN_MSG_INFO                tx_msg_info;
		
	while (1) {
		// Code pour envoyer les trames CAN
		
		osSignalWait(0x02,osWaitForever);			//Attente t�che utilisant le bus CAN
		
		tx_msg_info.id = ARM_CAN_STANDARD_ID(ID_USF);
		tx_msg_info.rtr = 0;									//trame de requete
		
		
		Driver_CAN1.MessageSend(1,&tx_msg_info, donnee_envoi_CAN, longueur_envoi_CAN);
		
		osSignalWait(0x01, osWaitForever);		// sommeil en attente fin emission
		osSemaphoreRelease(ID_sema_CAN);						//lib�ration du Semaphore
	}		
}




// tache reception
void CANthreadR(void const *argument)
{
	ARM_CAN_MSG_INFO   rx_msg_info;
	uint8_t data_buf[8];
	char texte[20], donnee[8],i,longueur;
	short id;
	GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
	
	while(1)
	{	
		osSignalWait(0x01, osWaitForever);		// sommeil en attente r�ception
		// Code pour reception trame + affichage Id et Data sur LCD
		//.............
		Driver_CAN1.MessageRead(0,&rx_msg_info,data_buf,8);
		id = rx_msg_info.id;
		longueur = rx_msg_info.dlc;
		for(i=0;i<longueur;i++)
		{
			donnee[i] = data_buf[i];
		}
		for(i=longueur;i<8;i++)
		{
			donnee[i] = 0;
		}
		
		switch(id){
			case ID_AU :
				//osSignalSet(id_STOOOOOOOOOOP,0x01);
				break;
			
			case ID_USF :
				dist_USF1 = donnee[0];
				dist_USF2 = donnee[1];
				dist_USF3 = donnee[2];
				sprintf(texte,"Donnee USF : 0x%02x", donnee[0]);
				GLCD_DrawString(0,50,texte);
				break;
			
			case ID_USM :
				dist_USM1 = donnee[0];
				dist_USM2 = donnee[1];
				break;
			
			case ID_USB :
				dist_USB1 = donnee[0];
				dist_USB2 = donnee[1];
				dist_USB3 = donnee[2];
				sprintf(texte,"Donnee USB : 0x%02x", dist_USB1);
				GLCD_DrawString(0,100,texte);
				break;
			
			case ID_LIDAR :
				
					//osSignalSet(id_LIDAAAAAAAR,0x01)
				
				break;
			case 0x3FF:
				sprintf(texte,"Donnee Etin : 0x%02x", donnee[0]);
				GLCD_DrawString(0,150,texte);
				break;
			default :
				break;
		}
			
			
			//osSignalSet(id_CANthreadT,0x02);
	}
}

// tache envoi du LIDAR
void tache_LIDAR(void const *argument)
{		
	while (1) {
		// Code de la t�che
		//**********************Envoi des donn�es sur le bus CAN**********************************
		
		/*
		//Envoi mise � jour des donn�es pour le CAN
		donnee_envoi_CAN[0] = i;
		longueur_envoi_CAN = 1;
		ID_envoi_CAN = ID_LED;
		
		osSignalSet(id_CANthreadT,0x02);			//Lib�ration de la t�che d'envoi sur le bus CAN
		*/
		//******************************Fin de l'envoi de donn�es**********************************
		
		osDelay(500);

	}		
}


osThreadDef(CANthreadR,osPriorityNormal, 1,0);
osThreadDef(CANthreadT,osPriorityNormal, 1,0);
osThreadDef(tache_LIDAR,osPriorityNormal,1,0);

/*
 * main: initialize and start the system
 */
int main (void) {
  osKernelInitialize ();                    // initialize CMSIS-RTOS

  // initialize peripherals here
	GLCD_Initialize();
	GLCD_ClearScreen();
	GLCD_SetFont(&GLCD_Font_16x24);
	
	// Initialisation des 2 p�riph�riques CAN
	InitCan1();

  // create 'thread' functions that start executing,
  // example: tid_name = osThreadCreate (osThread(name), NULL);
	id_CANthreadR = osThreadCreate (osThread(CANthreadR), NULL);
	id_CANthreadT = osThreadCreate (osThread(CANthreadT), NULL);
	id_tache_LIDAR = osThreadCreate (osThread(tache_LIDAR), NULL);
	
	ID_sema_CAN = osSemaphoreCreate(osSemaphore(sema_CAN),1) ; //Cr�ation du Semaphore

  osKernelStart ();                         // start thread execution 
	osDelay(osWaitForever);
}



