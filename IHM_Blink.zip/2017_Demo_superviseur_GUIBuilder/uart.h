/****************************************************************************
 *   Librairie des fonctions UART permettant l'utilisation de la carte d'extension avec MCB11C4 (KEIL)
 *	 IUT de Cachan - 13/12/2018
 *   Project: NXP LPC11xx UART example
 *
****************************************************************************/


void Init_UART(void);
void UART_TxString(char *pMsg);
void UART_Tx (char val);
char UART_Rx (void);

/*****************************************************************************
**                            End Of File
******************************************************************************/
