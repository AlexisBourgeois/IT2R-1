// Exemple utilisation ADC

#include "LPC11xx.h"
#include "GPIO.h"
#include "ADC.h"

int main(void)
{
	uint32_t 	valeur;
	Initialise_GPIO();
	ADC_init ();
	
	while (1)
	{
		ADC_startCnv();
		valeur =  ADC_getCnv ();
		
		Ecriture_GPIO(valeur/4);
	
	}
	
	return 0;
}
