// Utilisation Event UART en emission-reception

#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions

#include "Driver_USART.h"               // ::CMSIS Driver:USART
#include "Board_ADC.h"                  // ::Board Support:A/D Converter
#include "Board_GLCD.h"                 // ::Board Support:Graphic LCD
#include "GLCD_Config.h"                // Keil.MCB1700::Board Support:Graphic LCD
#include "LPC17xx.h"                    // Device header
#include "cmsis_os.h"                   // CMSIS RTOS header file
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

extern GLCD_FONT GLCD_Font_6x8;
extern GLCD_FONT GLCD_Font_16x24;

osMailQId maBAL;
osMailQDef(maBAL, 200, char);

void Thread_T (void const *argument);                             // thread function Transmit
osThreadId tid_Thread_T;                                          // thread id
osThreadDef (Thread_T, osPriorityNormal, 1, 0);                   // thread object

void Thread_R (void const *argument);                             // thread function Receive
osThreadId tid_Thread_R;                                          // thread id
osThreadDef (Thread_R, osPriorityNormal, 1, 0);                   // thread object

void Thread_D (void const *argument);                             // thread function Receive
osThreadId tid_Thread_D;                                          // thread id
osThreadDef (Thread_D, osPriorityNormal, 1, 0);                   // thread object

// prototypes fonctions
void Init_UART(void);
void sendCommand(char * command);
void Init_WiFi(void);
void DisplayTitre(void);
void sendData(char* Msg);

extern ARM_DRIVER_USART Driver_USART1;

//fonction de CallBack lancee si Event T ou R
void event_UART(uint32_t event)
{
	switch (event) {
		
		case ARM_USART_EVENT_RECEIVE_COMPLETE : 	
			osSignalSet(tid_Thread_R, 0x01);
			break;
		
		case ARM_USART_EVENT_SEND_COMPLETE  : 	
			osSignalSet(tid_Thread_T, 0x02);
			break;
		
		default : 
			break;
	}
}

int main (void){

	osKernelInitialize ();                    // initialize CMSIS-RTOS
	Init_UART();
	GLCD_Initialize();
	GLCD_ClearScreen();
	GLCD_SetFont(&GLCD_Font_16x24);
	ADC_Initialize();
	// initialize peripherals here 
	GLCD_SetBackgroundColor(GLCD_COLOR_WHITE );
	GLCD_ClearScreen();
	DisplayTitre();
		
	maBAL=osMailCreate(osMailQ(maBAL), NULL);
	NVIC_SetPriority(UART1_IRQn,2);
	
	//Creation of 3 tasks Thread_T, Thread_R & Thread_D
		tid_Thread_T = osThreadCreate (osThread(Thread_T), NULL);
		tid_Thread_R = osThreadCreate (osThread(Thread_R), NULL);
		tid_Thread_D = osThreadCreate (osThread(Thread_D), NULL);
	
	osKernelStart ();                         // start thread execution 
	
	osDelay(osWaitForever);
	
	return 0;
}

// Tache d'envoi des commandes
void Thread_T (void const *argument) {
	
	char ReqHTTP[90];
	int val=0;
	Init_WiFi();
	
	while(1)
		{
	ADC_StartConversion();
	while (ADC_ConversionDone()!=0);
	val = ADC_GetValue();
	/*sprintf(ReqHTTP,"La valeur : %d",val);
	GLCD_SetFont(&GLCD_Font_16x24);
	GLCD_SetForegroundColor(GLCD_COLOR_RED);*/
	sendCommand("AT+CIPSTART=\"UDP\",\"192.168.1.100\",1035\r\n");
	osDelay(2000);
   // Send Data to the Server (HyperTerminal test server or ThingSpeak server)
		sendData("Yahou\r\n");
	// Close Socket connection
		sendCommand("AT+CIPCLOSE\r\n");
  //  sendCommand("AT+CIPCLOSE\r\n");
	}
}

// Tache de réception
void Thread_R (void const *argument) {

	char RxChar,*pChar;
	
  while (1) {
		Driver_USART1.Receive(&RxChar,1);		// A mettre ds boucle pour recevoir 
		osSignalWait(0x01, osWaitForever);	// sommeil attente reception
		
		pChar=osMailAlloc(maBAL, osWaitForever);
		*pChar=RxChar;
		osMailPut (maBAL, pChar);
  }
}

// Tache d'affichage
void Thread_D (void const *argument) {

	char *pRxChar;
	osEvent RxEv;
	int ligne=26;
	int i=0;	// i pour position colonne caractère
	char RxBuf[200];
	int Reset=0,display=1;
	
  while (1) {
		RxEv = osMailGet (maBAL, osWaitForever);
		pRxChar=RxEv.value.p;
		
		RxBuf[i]=*pRxChar;
		i++;
		//Suivant le caractère récupéré
		switch(*pRxChar)
		{
			case 0x0D: 		//Un retour chariot? On ne le conserve pas...
				i--;
				break;
			case 0x0A:										//Un saut de ligne?
				RxBuf[i-1]=0;											//=> Fin de ligne, donc, on "cloture" la chaine de caractères
				
			  //Si mode AT+RST, BaudRate par défaut (74880bits/s): messages illisibles : On les détecte pour ne pas les afficher
				if(Reset==1)
				{
					if((strncmp("OK",RxBuf,2)!=0)&&(strncmp("WIFI",RxBuf,4)!=0)&&(strncmp("Ai-Th",RxBuf,5)!=0)&&(strncmp("ready",RxBuf,5)!=0))
						display=0;
					else
						display=1;
				}				
				
				//Fin de la commande AT+RST, on peut donc afficher à nouveau
				if(strncmp("ready",RxBuf,5)==0)
					Reset=0;				
				
				//Indicateur de passage en mode AT+RST
				if(strcmp("AT+RST",RxBuf)==0)
					Reset=1;
				
				//Colorisation de certains types de messages
				if(strncmp("AT+",RxBuf,3)==0)
					GLCD_SetForegroundColor(GLCD_COLOR_BLUE);
				else
				{
					if(strcmp("OK",RxBuf)==0)
						GLCD_SetForegroundColor(GLCD_COLOR_GREEN);
					else
					{
						if((strncmp("FAIL",RxBuf,4)==0)||(strncmp("ERROR",RxBuf,5)==0))
							GLCD_SetForegroundColor(GLCD_COLOR_RED);
						else
							GLCD_SetForegroundColor(GLCD_COLOR_DARK_GREY);	
					}
				}
				
				//Si on est en mode normal (PAS AT+RST), on affiche la ligne reçue
				if(display==1)
				{
					GLCD_DrawString(1,ligne,RxBuf);	//On l'affiche (peut etre trop long, donc perte des caractères suivants??)
					ligne+=10;										//On "saute" une ligne de l'afficheur LCD
			  }
				
				//Gestion d'affichage par pages
				if(ligne>230)
				{
					ligne=26;
					osDelay(2000);
					GLCD_ClearScreen();
					DisplayTitre();
				}
				i=0;													//On se remet au début du buffer de réception pour la prochaine ligne à recevoir

				if((strcmp("OK",RxBuf)==0)||(strcmp("SEND OK",RxBuf)==0))
					osSignalSet(tid_Thread_T, 0x04);
				else
				{
					if(strcmp("ready",RxBuf)==0)
						osSignalSet(tid_Thread_T, 0x06);
				}
				break;
		}
		osMailFree(maBAL, pRxChar);
  }
}

void Init_UART(){
	Driver_USART1.Initialize(event_UART);
	Driver_USART1.PowerControl(ARM_POWER_FULL);
	Driver_USART1.Control(	ARM_USART_MODE_ASYNCHRONOUS |
							ARM_USART_FLOW_CONTROL_NONE   |
							ARM_USART_DATA_BITS_8		|
							ARM_USART_STOP_BITS_1		|
							ARM_USART_PARITY_NONE		,							
							9600);
	Driver_USART1.Control(ARM_USART_CONTROL_TX,1);
	Driver_USART1.Control(ARM_USART_CONTROL_RX,1);
}

void sendCommand(char * command)
{
	int len;
	len = strlen (command);
	Driver_USART1.Send(command,len); // send the read character to the esp8266
	osSignalWait(0x02, osWaitForever);		// sommeil fin emission	
	if(strncmp("AT+RST",command,6)==0)
		osSignalWait(0x06, osWaitForever);		// sommeil fin commande RST
	else
		osSignalWait(0x04, osWaitForever);		// sommeil fin autres commande
}

void Init_WiFi(void)
{
	GLCD_SetFont(&GLCD_Font_6x8);
	// reset module
		sendCommand("AT+RST\r\n");
    // configure as Station 
		sendCommand("AT+CWMODE=1\r\n");
	// disconnect from any previous Access Point
		sendCommand("AT+CWQAP\r\n");
	//Connect to YOUR Access Point
		sendCommand("AT+CWJAP=\"ciscoG5\",\"cachanit2rG5\"\r\n");
	//Display IP parameters
}

void DisplayTitre(void)
{
	/*GLCD_SetFont(&GLCD_Font_16x24);
	GLCD_SetForegroundColor(GLCD_COLOR_PURPLE);
	GLCD_DrawString(0,0,"IoT->ThingSpeak");
	GLCD_SetFont(&GLCD_Font_6x8);
	GLCD_DrawString(260,11,"(Client)");
	GLCD_SetForegroundColor(GLCD_COLOR_DARK_GREY);*/
}

void sendData(char* data)
{
	char Msg[50];
	sprintf(Msg,"AT+CIPSEND=%d\r\n",strlen(data));
	sendCommand(Msg);
	sendCommand(data);
}
