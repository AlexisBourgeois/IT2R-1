
#include "LPC11xx.h" 

void Initialise_GPIO (void);
char Valeur_BP4(void);
char Valeur_BP5(void);
void Allumer_1LED(char Num_LED);
void Eteindre_1LED(char Num_LED);
void Ecriture_GPIO(unsigned char Valeur);





