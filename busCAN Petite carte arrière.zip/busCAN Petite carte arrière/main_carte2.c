/*----------------------------------------------------------------------------
 * Programme Exemple utilisation biblioth�ques CAN OnChip
 * Carte 2 : 
 * - Attend la trame Id 0x020 et affiche en LED la premi�re data
 * - Envoie la trame Id 0x010 de data 1 2 3 4  (1�re data = 'S'), d�lai 1s
 * Attention : Bien v�rifier que la zone RAM autoris�e commence � 0x100000C0 (voir Options for Target)
 *---------------------------------------------------------------------------*/

#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions
#include "LPC11xx.h"                    		// Device header
#include "GPIO.h"

#include "cmsis_os.h"                                           // CMSIS RTOS header file

#include "rom_drivers.h"

#ifndef NULL
#define NULL    ((void *)0)
#endif

/*----------------------------------------------------------------------------------------*
 * Definition des identifiants du bus CAN pour permettre la communication dans la voiture *
 *----------------------------------------------------------------------------------------*/
#define ID_AU 		0x002		//arret d'urgence
#define ID_USF 		0x027		//Ultrasons avant
#define ID_USM 		0x043		//Ultrasons milieu
#define ID_USB 		0x033		//Ultrasons arri�re
#define ID_LED 		0x065		//Commande de la barre de DEL arri�re
#define ID_PHARE	0x085		//Allumage des phares
#define ID_GPS 		0x0C5		//G�olocalisation GPS
#define ID_LIDAR	0x113		//Analyse de l'environnement
#define ID_TEST		0x3FF		//Identifiant pour faire des test : PAS UTILISE DANS LA VOITURE

#define FILTRE_CARTE_D	0x001		//Carte arri�re
#define FILTRE_CARTE_S	0x002		//Carte centrale
#define FILTRE_CARTE_L	0x004		//Carte avant

#define DATA_REQUETE 0xB1 //Donn�e que l'on envoie lors d'une requ�te sur bus CAN

osSemaphoreId ID_sema_CAN; // Semaphore pour acc�s bus CAN
osSemaphoreDef (sema_CAN);

//******************Variables globales de l'envoi sur bus CAN******************
uint8_t donnee_envoi_CAN[8];
char longueur_envoi_CAN, reception_CAN[8];
short ID_envoi_CAN;

char CAN_recep_LED;
char CAN_recep_USF;

// Pointeur sur la ROM contenant les fonctions CAN
ROM **rom = (ROM **)0x1fff1ff8;

// Objets CAN de reception et emission
CAN_MSG_OBJ msg_objR, msg_objT;	

void Thread_R (void const *argument);                             // thread reception
void Thread_T (void const *argument);                             // thread emission
void Thread_LED (void const *argument);														// thread pour g�rer les DEL
void Thread_USB (void const *argument);														// thread pour g�rer les ultrasons arri�re

osThreadId tid_Thread_R, tid_Thread_T, tid_LED, tid_USB;          // thread id
osThreadDef (Thread_LED, osPriorityNormal, 1, 0);
osThreadDef (Thread_R, osPriorityNormal, 1, 0);                   // thread object
osThreadDef (Thread_T, osPriorityNormal, 1, 0);                   // thread object
osThreadDef (Thread_USB, osPriorityNormal, 1, 0);                 // thread object

// Protos Initialisation
void Init_CAN(void);
void Init_LPC11C14(void);

/* Protos fonctions Callback */
void CAN_rx(uint8_t msg_obj_num);
void CAN_tx(uint8_t msg_obj_num);
void CAN_error(uint32_t error_info);

/* Publish CAN Callback Functions */
CAN_CALLBACKS callbacks = {
   CAN_rx,
   CAN_tx,
   CAN_error,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL,
};


/*
 * main: initialize and start the system
 */
int main (void) {
  osKernelInitialize ();                    // initialize CMSIS-RTOS

  // initialize peripherals here
	Init_LPC11C14();
	Init_CAN();
	
	Initialise_GPIO();
	Ecriture_GPIO(0);
	
  // Creation des threads
	tid_Thread_R = osThreadCreate (osThread(Thread_R), NULL);
	tid_Thread_T = osThreadCreate (osThread(Thread_T), NULL);
	tid_LED = osThreadCreate (osThread(Thread_LED), NULL);
	tid_USB = osThreadCreate (osThread(Thread_USB), NULL);
	
	//Cr�ation du Semaphore du bus CAN
	ID_sema_CAN = osSemaphoreCreate(osSemaphore(sema_CAN),1);
	
  osKernelStart ();                         // start thread execution 
	osDelay(osWaitForever);
}

//****************************Thread de reception**********************************
void Thread_R (void const *argument) {

	char recu[8];
	int id, taille,i;
	
  while (1) {
		osSignalWait(0x01,osWaitForever);	// on attend l'EVENT RECEP fonction CB

		/* On recupere l'objet CAN recu */
		(*rom)->pCAND->can_receive(&msg_objR);

    /* On traite la trame recue */
    id = msg_objR.mode_id ;
		taille = msg_objR.dlc;
		
		for (i=0;i<taille;i++) recu[i] = msg_objR.data[i];
		for (i=taille;i<8;i++) recu[i] = 0x00;
		
		for (i=0;i<taille;i++) recu[i] = msg_objR.data[i];
		for (i=taille;i<8;i++) recu[i] = 0x00;

		switch(id){
			case ID_USF:
				if(taille == 1) CAN_recep_USF = recu[0]; 
				break;
			case ID_USM:
				break;
			case ID_USB:
				break;
			case ID_GPS:
				break;
			case ID_LED:
				Ecriture_GPIO(8);
				break;
			case ID_PHARE:
				break;
			case ID_LIDAR:
				break;
			case ID_TEST:
				break;
			default :
				break;
		}
		
		// Affichage LED
  }
}

//****************************Thread d'�mission************************************
void Thread_T (void const *argument) {

	char T = 0;
	
  while (1) {
		
		osSignalWait(0x02,osWaitForever);			//Attente t�che utilisant le bus CAN
		
		/* Envoi d'une trame CAN ID_envoi_CAN sur objet 0 */
		msg_objT.msgobj  = 0;
		msg_objT.mode_id = ID_envoi_CAN;
		msg_objT.mask    = 0x0;
		msg_objT.dlc     = longueur_envoi_CAN;			// 1 data a envoyer

		for(T=0;T<longueur_envoi_CAN;T++)
		{
				msg_objT.data[T] = donnee_envoi_CAN[T];	
		}
		
		// envoi de la trame
    (*rom)->pCAND->can_transmit(&msg_objT);
		
 		
		osSemaphoreRelease(ID_sema_CAN);						//lib�ration du Semaphore
  }
}

//****************************Tache permettant l'allumage d'une LED**********************
void Thread_LED (void const *argument){
	
	uint8_t data_buf[8];
	char allumage;
	short id_env;
	unsigned char j=0xFF;
		
	while (1) {
		// Code de la t�che
		
		allumage = CAN_recep_USF;		//Stockage dans une variable locale des donn�es envoy�es sur le bus CAN
		
		Ecriture_GPIO(allumage);

		
		//**********************Envoi des donn�es sur le bus CAN**********************************
		
		osSemaphoreWait(ID_sema_CAN,osWaitForever);						//synchro sur Semaphore
		
		//Envoi mise � jour des donn�es pour le CAN

		donnee_envoi_CAN[0] = j;		//Donn�es du bus CAN
		longueur_envoi_CAN = 1;			//Longueur des donn�es envoy�es
		ID_envoi_CAN = ID_TEST;			//Identifiant de la trame
		
		osSignalSet(tid_Thread_T,0x02);			//Lib�ration de la t�che d'envoi sur le bus CAN
		
		//******************************Fin de l'envoi de donn�es**********************************
		if(j>1)j--;
		else j=0xff;
		osDelay(200);
		
	}	
}

//****************************Tache permettant d'envoyer les donn�es des capteurs � ultrasons arri�re**********************
void Thread_USB (void const *argument){
	
	uint8_t data_buf[8];
	char allumage;
	short id_env;
	unsigned char i = 0x01;
		
	while (1) {
		// Code de la t�che
		
		
		//**********************Envoi des donn�es sur le bus CAN**********************************
		
		osSemaphoreWait(ID_sema_CAN,osWaitForever);						//synchro sur Semaphore
		
		//Envoi mise � jour des donn�es pour le CAN

		donnee_envoi_CAN[0] = i;		//Donn�es du bus CAN
		longueur_envoi_CAN = 1;			//Longueur des donn�es envoy�es
		ID_envoi_CAN = ID_USB;			//Identifiant de la trame

		osSignalSet(tid_Thread_T,0x02);			//Lib�ration de la t�che d'envoi sur le bus CAN
		
		//******************************Fin de l'envoi de donn�es**********************************
		if(i<255)i++;
		else i=0;
		osDelay(250);
		
	}	
}

void Init_LPC11C14(void) {
	SystemCoreClockUpdate();

	/* Output the Clk onto the CLKOUT Pin PIO0_1 to monitor the freq on a scope */
	LPC_IOCON->PIO0_1	= (1<<0);
	/* Select the MAIN clock as the clock out selection since it's driving the core */
	LPC_SYSCON->CLKOUTCLKSEL = 3;
	/* Set CLKOUTDIV to 6 */
	LPC_SYSCON->CLKOUTDIV = 10;		//	CLKOUT Divider = 10
	/* Enable CLKOUT */
	LPC_SYSCON->CLKOUTUEN = 0;
	LPC_SYSCON->CLKOUTUEN = 1;
	while (!(LPC_SYSCON->CLKOUTUEN & 0x01));
	
}

void Init_CAN(void) {
	
	//CAN sur broche CAN P2
	uint32_t ClkInitTable[2] = {
  0x00000000UL, // CANCLKDIV		//
  0x00001C57UL  // CAN_BTR			// -> 125 kHz
	};
	
	/* Initialisation du controlleur CAN */
	(*rom)->pCAND->init_can(&ClkInitTable[0], 1);

	/* Configuration des fonctions CB pour CAN */
	(*rom)->pCAND->config_calb(&callbacks);

	/* Enable IRQ CAN */
	NVIC_EnableIRQ(CAN_IRQn);
	
	/* Object 1 pour reception des Id 11 bits 0x0c8 */
	msg_objR.msgobj = 1;
	msg_objR.mode_id = FILTRE_CARTE_D;
	msg_objR.mask = FILTRE_CARTE_D;
	(*rom)->pCAND->config_rxmsgobj(&msg_objR);	
}

/*	CAN receive callback */
/*	Function is executed by the Callback handler after
	a CAN message has been received */
void CAN_rx(uint8_t msg_obj_num){
  osSignalSet(tid_Thread_R, 0x01);	// on reveille la tache en attente de reception
  return;
}

/*	CAN transmit callback */
/*	Function is executed by the Callback handler after
	a CAN message has been transmitted */
void CAN_tx(uint8_t msg_obj_num){
	osSignalSet(tid_Thread_T, 0x01);	// on reveille la tache d'envoi en attente fin envoi
  return;
}

/*	CAN error callback */
/*	Function is executed by the Callback handler after
	an error has occured on the CAN bus */
void CAN_error(uint32_t error_info){
  return;
}

/*	CAN interrupt handler */
/*	The CAN interrupt handler must be provided by the user application.
	It's function is to call the isr() API located in the ROM */
void CAN_IRQHandler (void){
  (*rom)->pCAND->isr();
}
