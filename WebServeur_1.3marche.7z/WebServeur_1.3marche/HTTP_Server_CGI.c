/*------------------------------------------------------------------------------
 * Serveur Web embarqu� - Script CGI
 * GE2 parcours IT2R - IUT de Cachan
 *------------------------------------------------------------------------------
 * Name:    HTTP_Server_CGI.c
 * Purpose: Serveur web HTTP
 * Modif: le 31/01/2016 pour la Team IT2R
 *----------------------------------------------------------------------------*/
#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions
#include "cmsis_os.h"                   /* CMSIS RTOS definitions             */
#include "rl_net.h"                     /* Network definitions                */
#include <stdio.h>
#include <string.h>
#include "rl_net.h"
#include "Board_GLCD.h"
#include "Board_ADC.h"
#include "Board_LED.h"


uint8_t ip_addr[NET_ADDR_IP4_LEN];
uint8_t mask[NET_ADDR_IP4_LEN];
uint8_t gateway[NET_ADDR_IP4_LEN];
uint8_t pri_dns[NET_ADDR_IP4_LEN];
uint8_t sec_dns[NET_ADDR_IP4_LEN];

extern GLCD_FONT GLCD_Font_6x8;
extern GLCD_FONT GLCD_Font_16x24;
extern uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len);

typedef struct {
	char udp[30];
	short val[10];
} Noot;


extern void tache1(void const *argument);
extern osThreadId ID_tache1 ;

osMailQId ID_BAL;
int k=0;


char lcd_text[20+1],P2=0;

/*int main1(void){
	osKernelInitialize (); 
	
	ID_tache1 = osThreadCreate ( osThread ( tache1 ), NULL );
	ID_BAL = osMailCreate(osMailQ(BAL),NULL);
	
  osKernelStart ();                         // start thread execution 
	osDelay(osWaitForever) ;	// start thread execution
	return 0;
}*/




uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len);

// Fonction de gestions des requetes de type POST.
// \param[in]     code          type de donn�es � g�rer :
//                              - 0 = www-url-encoded form data,
//                              - sinon = autre (hors programme)
// \param[in]     data          pointeur sur donnee POST
// \param[in]     len           longueur donnee POST.
void netCGI_ProcessData (uint8_t code, const char *data, uint32_t len) {
  char var[30];
	char strlcd[5];
	char strled[5];
	char strledcheck[7];
	char retlcd=0,retled=0;
	
	strcpy(strlcd,"lcd1=");	
	strcpy(strled,"led0=");
	strcpy(strledcheck,"checked");
	

	if (code != 0) {
    // Les autres codes sont ignor�s
    return;
  }
	
  if (len == 0) {
    // Si pas de donn�e � traiter
    return;
  }
		
  do {
    // Appel de la fonction d'analyse de la trame "POST"
    data = netCGI_GetEnvVar (data, var, sizeof (var));	// var contient la donn�e � g�rer
    if (var[0] != 0) {
      // si il y a une donn�e � g�rer
			//METTRE ICI LE TRAITEMENT DE LA CHAINE ENVOYE PAR LE NAVIGATEUR
			retlcd=strncmp(&strlcd[0],&var[0],5); //G�re si c'est bien la trame du LCD
			retled=strncmp(&strled[0],&var[0],5); //G�re si c'est bien la trame de la LED
			
			if (retlcd==0){ 
			strcpy(lcd_text,&var[5]);
		}
			
			if (retled==0){
				P2= var[5];
				//P2 = strncmp(&strledcheck[0],&var[5],7);
				sprintf(lcd_text,"%c",P2);
				GLCD_DrawString         (3, 1, lcd_text);
				if (P2==1) LED_On(0);
				else LED_Off(0);
				
		}
		
			//FIN TRAITEMENT TRAME
			GLCD_DrawString(100,100,lcd_text);	// colonne puis ligne en pixel
			GLCD_DrawString(100,100,lcd_text);	// colonne puis ligne en pixel
    }
  } while (data);			// Tant qu'il a a des donn�es � traiter
	
}
 

// Fonction de g�n�ration des lignes CGI � mettre � jour
// \param[in]     env           environment string.
// \param[out]    buf           output data buffer.
// \return        number of bytes written to output buffer.
uint32_t netCGI_Script (const char *env, char *buf, uint32_t buf_len, uint32_t *pcgi) {
  uint32_t len = 0;
	Noot *ptr;
	char table[30];
  switch (env[0]) {
		osDelay(300);
    case 'a':
      // Mise a jour du champ du script CGI
      len = sprintf (buf,&env[2],ptr->val[0]);
			 break;
		case 'b': 
			sprintf(table,"%d",ptr->val[1]);
			len = sprintf(buf,&env[2] ,ptr->val[1]);
			break;
		case 'c': 
			sprintf(table,"%d",ptr->val[2]);
			len=sprintf(buf , &env[2] ,ptr->val[2]);

				break;
		}
  return (len);

 }

 uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len) {
	char i;
	int k;
	Noot *ptr;
	char tab[20];
  if ((buf[0] != 0x00) && (len==25)){
		for (i=0;i<=len;i++){
		ptr->udp[i]=buf[i]; //Copie toutes les valeurs de la cha�ne et les mets dans tableau
		}
	GLCD_SetFont(&GLCD_Font_6x8);
	sprintf(tab,"1 %s",ptr->udp);
	GLCD_DrawString(0,100,tab);
	}
	ptr= osMailAlloc(ID_BAL,500);
	osMailPut(ID_BAL,ptr->udp);
  return (0);
}

void tache1(void const *argument){
	Noot *ptr;
	osEvent Trame_recu;
	//const char delim[2]= "#";
	//char copie[30];
	int str[10];
	char *token;
	char i=0,j=0;
	char tab[20];
	
	while(1){
	Trame_recu = osMailGet(ID_BAL,osWaitForever); //On attend la trame UDP
	sprintf(tab,"2 %s",ptr->udp);
	GLCD_DrawString(0,130,tab);
	osDelay(100);

	
	//for (i=0;i<sizeof(ptr->udp);i++) copie[i]=ptr->udp[i];
	osMailFree(ID_BAL, ptr);
	
	token = strtok(tab,"#"); //On parcours le tableau jusqu'au d�limiteur
		
	while(token!=NULL){
		//GLCD_DrawString(0,100,token);
		str[i]=*token; //On met dans chaque case du tableau la valeur correspondante
		token=strtok(NULL,"#"); //Supprime ce qui a �t� trait�, et recommence jusqu'au prochain d�limiteur
	}
	for (j=0;j<3;j++){ //On enrengistre dans notre tableau pour l'afficher plus tard dans NetCGI
		ptr->val[j]=str[j];
	}
	}
}