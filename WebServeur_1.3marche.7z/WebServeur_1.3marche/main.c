/*------------------------------------------------------------------------------
 * Serveur Web embarqu� 
 * GE2 parcours IT2R - IUT de Cachan
 *------------------------------------------------------------------------------
 * Name:    main.c
 * Purpose: Serveur web HTTP
 * Modif: le 31/01/2016 pour la Team IT2R
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include "rl_net.h"                     /* Network definitions                */
#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions
#include "cmsis_os.h"                   /* CMSIS RTOS definitions             */
#include "Board_GLCD.h"
#include "GLCD_Config.h"
#include "Board_LED.h"
#include "Board_Buttons.h"
#include "Board_ADC.h"

extern GLCD_FONT GLCD_Font_6x8;
extern GLCD_FONT GLCD_Font_16x24;

extern struct {
	char udp[30];
	short val[10];
} Noot;

void tache1(void const *argument);
osThreadId ID_tache1 ;
osThreadDef(tache1, osPriorityNormal, 1, 0); // 1 instance, taille pile par d�faut 

extern osMailQId ID_BAL;
osMailQDef(BAL,16,Noot);

int adv2;
uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len);
/*----------------------------------------------------------------------------
  Thread principale : gestion r�seau
 *---------------------------------------------------------------------------*/
int main (void) {
	char tab[50];
	int32_t udp_sock;  
	osKernelInitialize (); 
	GLCD_Initialize();
	GLCD_ClearScreen();
	GLCD_SetFont(&GLCD_Font_16x24);
  GLCD_DrawString         (0, 1, "Mon premier serveur web");
	LED_Initialize     ();
  ADC_Initialize     ();
	netInitialize ();
	
	ID_tache1 = osThreadCreate ( osThread ( tache1 ), NULL );
	ID_BAL = osMailCreate(osMailQ(BAL),NULL);
	
	udp_sock = netUDP_GetSocket (udp_cb_func);
	osKernelStart ();                         // start thread execution 
	
  while(1)
	{
	if (udp_sock > 0) {
    netUDP_Open (udp_sock, 2020);
  }
	  
  }
	
	return 0;
}

/*uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len) {
 
  // Data received
  if ((buf[0] == 0x01) && (len == 2)) {
    // Switch LEDs on and off
    // LED_out (buf[1]);
  }
  
  return (0);
}*/

