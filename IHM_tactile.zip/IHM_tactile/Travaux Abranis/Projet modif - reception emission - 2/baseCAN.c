/*---------------------------------------------------
* CAN 2 uniquement en TX 
* + r�ception CAN1 
* avec RTOS et utilisation des fonction CB
* pour test sur 1 carte -> relier CAN1 et CAN2
* 2017-04-02 - XM
---------------------------------------------------*/

#define osObjectsPublic                     // define objects in main module
// #include "osObjects.h"                      // RTOS object definitions
#include "LPC17xx.h"                    // Device header
#include "Driver_CAN.h"                 // ::CMSIS Driver:CAN
#include "Board_GLCD.h"                 // ::Board Support:Graphic LCD
#include "GLCD_Config.h"                // Keil.MCB1700::Board Support:Graphic LCD
#include "stdio.h"
#include "cmsis_os.h"



extern GLCD_FONT GLCD_Font_6x8;
extern GLCD_FONT GLCD_Font_16x24;

osThreadId id_CANthreadR;
osThreadId id_CANthreadT;

extern   ARM_DRIVER_CAN         Driver_CAN1;
extern   ARM_DRIVER_CAN         Driver_CAN2;

// CAN1 utilis� pour r�ception
void myCAN1_callback(uint32_t obj_idx, uint32_t event)
{
    switch (event)
    {
    case ARM_CAN_EVENT_RECEIVE:
        /*  Message was received successfully by the obj_idx object. */
       osSignalSet(id_CANthreadR, 0x01);
        break;
    }
}

// CAN2 utilis� pour �mission
void myCAN2_callback(uint32_t obj_idx, uint32_t event)
{
    switch (event)
    {
    case ARM_CAN_EVENT_SEND_COMPLETE:
        /* 	Message was sent successfully by the obj_idx object.  */
        osSignalSet(id_CANthreadT, 0x01);
        break;
    }
}

// CAN1 utilis� pour r�ception
void InitCan1 (void) {
	Driver_CAN1.Initialize(NULL,myCAN1_callback);
	Driver_CAN1.PowerControl(ARM_POWER_FULL);
	
	Driver_CAN1.SetMode(ARM_CAN_MODE_INITIALIZATION);
	Driver_CAN1.SetBitrate( ARM_CAN_BITRATE_NOMINAL,
													125000,
													ARM_CAN_BIT_PROP_SEG(5U)   |         // Set propagation segment to 5 time quanta
                          ARM_CAN_BIT_PHASE_SEG1(1U) |         // Set phase segment 1 to 1 time quantum (sample point at 87.5% of bit time)
                          ARM_CAN_BIT_PHASE_SEG2(1U) |         // Set phase segment 2 to 1 time quantum (total bit is 8 time quanta long)
                          ARM_CAN_BIT_SJW(1U));                // Resynchronization jump width is same as phase segment 2
  Driver_CAN1.ObjectConfigure(1,ARM_CAN_OBJ_TX); // Objet 1 pour �mission
  Driver_CAN1.ObjectConfigure(0,ARM_CAN_OBJ_RX); // Objet 0 pour r�ception
  Driver_CAN1.SetMode(ARM_CAN_MODE_NORMAL); // fin initialization
                       
	// Mettre ici les filtres ID de r�ception sur objet 0
	//....................................................
		
	Driver_CAN1.ObjectConfigure(0,ARM_CAN_OBJ_RX);				// Objet 0 du CAN1 pour r�ception
	
	Driver_CAN1.SetMode(ARM_CAN_MODE_NORMAL);					// fin init
}



// CAN2 utilis� pour �mission
void InitCan2 (void) {
	Driver_CAN2.Initialize(NULL,myCAN2_callback);
	Driver_CAN2.PowerControl(ARM_POWER_FULL);
	
	Driver_CAN2.SetMode(ARM_CAN_MODE_INITIALIZATION);
	Driver_CAN2.SetBitrate( ARM_CAN_BITRATE_NOMINAL,
													125000,
													ARM_CAN_BIT_PROP_SEG(5U)   |         // Set propagation segment to 5 time quanta
                          ARM_CAN_BIT_PHASE_SEG1(1U) |         // Set phase segment 1 to 1 time quantum (sample point at 87.5% of bit time)
                          ARM_CAN_BIT_PHASE_SEG2(1U) |         // Set phase segment 2 to 1 time quantum (total bit is 8 time quanta long)
                          ARM_CAN_BIT_SJW(1U));                // Resynchronization jump width is same as phase segment 2
	Driver_CAN2.ObjectConfigure(1,ARM_CAN_OBJ_TX); // Objet 1 pour �mission
  Driver_CAN2.ObjectConfigure(0,ARM_CAN_OBJ_RX); // Objet 0 pour r�ception
  Driver_CAN2.SetMode(ARM_CAN_MODE_NORMAL); // fin initialisation

	// Code d'initialisation du CAN2 en TX
	//.............
	
}






// tache envoi toutes les secondes
void CANthreadT(void const *argument)
{

}

// tache reception
 void CANthreadR(void const *argument)
 {
	ARM_CAN_MSG_INFO   rx_msg_info;
	uint8_t data_buf[8];
	char texte[10];
	int identifiant;
	char data0, data1, data2, data3, data4, data5, data6, data7, taille;
	
	while(1)
	{	
		
		//emission
		  
		ARM_CAN_MSG_INFO tx_msg_info;
		
		//reception
		
		Driver_CAN1.MessageRead(0, &rx_msg_info, data_buf, 8); // 8 data max
	 identifiant = rx_msg_info.id; // (int)
	 data0 = data_buf [0]; // 1�re donn�e de la trame r�cup�r�e (char)
	 taille = rx_msg_info.dlc; // nb data (char) Rem : fonction callback en approche...
		sprintf(texte, "ID=0x%x   DATA=0x%x    ", identifiant, data0);  // creation de chaine de carachtere	
    GLCD_DrawString(1,0,(unsigned char*)texte); // affichage identifiant et valeur re�u 
		


   //emission
		
		
			tx_msg_info.id = ARM_CAN_STANDARD_ID (identifiant);
			tx_msg_info.rtr = 0; // 0 = trame DATA
			data_buf [0] = data0;
			data_buf [1] = data1;
			data_buf [2] = data2;
			data_buf [3] = data3;
			data_buf [4] = data4;
			data_buf [5] = data5;
			data_buf [6] = data6;
			data_buf [7] = data7;
			Driver_CAN2.MessageSend(1, &tx_msg_info, data_buf, 8);
			

//		osSignalWait(0x01, osWaitForever);		// sommeil en attente r�ception
		
		// Code pour reception trame + affichage Id et Data sur LCD
		//.............

	}
 }


osThreadDef(CANthreadR,osPriorityNormal, 1,0);
osThreadDef(CANthreadT,osPriorityNormal, 1,0);



//* main: initialize and start the system
int main (void) {
  Initialise_GPIO();
	osKernelInitialize ();                    // initialize CMSIS-RTOS

  // initialize peripherals here
	GLCD_Initialize();
	GLCD_ClearScreen();
	GLCD_SetFont(&GLCD_Font_16x24);
	
	// Initialisation des 2 p�riph�riques CAN
	InitCan1();
	InitCan2();
	
	
	LPC_SC->PCONP |= (1<<22);
	
	LPC_TIM0->PR = 250000-1; 
  LPC_TIM0->MR0 = 19; 

  LPC_TIM0->MCR |= (1<<1);
  LPC_TIM0->EMR |= (3<<4);
	LPC_TIM0->TCR = 1;
	



				

  // create 'thread' functions that start executing,
  // example: tid_name = osThreadCreate (osThread(name), NULL);
	id_CANthreadR = osThreadCreate (osThread(CANthreadR), NULL);
	id_CANthreadT = osThreadCreate (osThread(CANthreadT), NULL);
	
	

				
  osKernelStart ();                         // start thread execution 
	osDelay(osWaitForever);
}

