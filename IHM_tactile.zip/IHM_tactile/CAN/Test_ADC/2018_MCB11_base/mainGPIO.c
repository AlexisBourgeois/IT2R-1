// Exemple gestion GPIO

#include "LPC11xx.h"
#include "GPIO.h"

int main(void)
{
	Initialise_GPIO();
	
	while (1)
	{
		if ( Valeur_BP4()==1) Allumer_1LED (4);
			else Eteindre_1LED (4);
		
		if ( Valeur_BP5()==1) Allumer_1LED (5);
			else Eteindre_1LED (5);
		
		
	}
	
	return 0;
}
