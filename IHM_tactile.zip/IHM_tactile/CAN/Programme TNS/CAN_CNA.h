
// Librairie des fonctions permettant l'initialisation des CAN/CNA (KEIL)
// IUT de Cachan - 03/12/2014 

void ADC_Init (void);
void DAC_Init(void);
int Conversion_AN(void);
void Conversion_NA(int sortie);
