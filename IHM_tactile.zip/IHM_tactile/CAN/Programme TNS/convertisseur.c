#include "CAN_CNA.h"
#include "LPC17xx.h"
#include "GPIO.h"
#define Gain 1.0

int entree[3], sortie[3];
float fentree[3], fsortie[3];
float A[3]={1, -1.944175567362, 0.946848127712}, B[3]= {0.02657593614398, 0, -0.02657593614398};

void Timer_Init(unsigned int prescaler, unsigned int valeur);
	
void TIMER0_IRQHandler(void)
{

	LPC_TIM0->IR = LPC_TIM0->IR | (1<<0); //RAZ du drapeau
	
	Allumer_1LED(0);
	
	entree[0] = Conversion_AN(); //Acquisitiion echantillon
	fentree[0] = (float)entree[0];
	fsortie[0] = B[0]*fentree[0]+B[1]*fentree[1]+B[2]*fentree[2]-A[1]*fsortie[1]-A[2]*fsortie[2] ; /* traitement num�rique */

				/* Saturation */
	if (fsortie[0] > 2047) fsortie[0] = 2047;
	else if (fsortie[0] < -2048) fsortie[0] = -2048;
	
	sortie[0] = (int)fsortie[0];
	Conversion_NA(sortie[0]); //Emission vers CNA
	
	/*Memorisation*/
	fentree[2]=fentree[1];
	fentree[1]=fentree[0];
	fsortie[2]=fsortie[1];
	fsortie[1]=fsortie[0];
	
	Eteindre_1LED(0);
}

int main(void){
	
	int prescaler = 0, valeur = 566;
	
	Initialise_GPIO ();
	
	ADC_Init(); /* initialisation CAN */
	DAC_Init(); /* initialisation CNA */
	
	Timer_Init(prescaler,valeur);
	NVIC_EnableIRQ(TIMER0_IRQn);
	
	while(1){
		}
	
return 0;
}

void Timer_Init(unsigned int prescaler, unsigned int valeur)
{
	LPC_TIM0->PR= prescaler;
	LPC_TIM0->MR0= valeur;
	LPC_TIM0->MCR=LPC_TIM0->MCR | (3<<0); //RAZ du compteur et interruption
	LPC_TIM0->TCR=1;
}