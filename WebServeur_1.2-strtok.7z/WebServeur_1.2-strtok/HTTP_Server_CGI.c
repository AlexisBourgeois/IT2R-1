/*------------------------------------------------------------------------------
 * Serveur Web embarqu� - Script CGI
 * GE2 parcours IT2R - IUT de Cachan
 *------------------------------------------------------------------------------
 * Name:    HTTP_Server_CGI.c
 * Purpose: Serveur web HTTP
 * Modif: le 31/01/2016 pour la Team IT2R
 *----------------------------------------------------------------------------*/
#include "cmsis_os.h"                   /* CMSIS RTOS definitions             */
#include "rl_net.h"                     /* Network definitions                */
#include <stdio.h>
#include <string.h>
#include "rl_net.h"
#include "Board_GLCD.h"
#include "Board_ADC.h"
#include "Board_LED.h"

uint8_t ip_addr[NET_ADDR_IP4_LEN];
uint8_t mask[NET_ADDR_IP4_LEN];
uint8_t gateway[NET_ADDR_IP4_LEN];
uint8_t pri_dns[NET_ADDR_IP4_LEN];
uint8_t sec_dns[NET_ADDR_IP4_LEN];

extern GLCD_FONT GLCD_Font_6x8;
extern GLCD_FONT GLCD_Font_16x24;
extern uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len);
extern int adv2;

char lcd_text[20+1],P2=0;
char table[10];
char fantome[10];
char ID[2];

uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len);

// Fonction de gestions des requetes de type POST.
// \param[in]     code          type de donn�es � g�rer :
//                              - 0 = www-url-encoded form data,
//                              - sinon = autre (hors programme)
// \param[in]     data          pointeur sur donnee POST
// \param[in]     len           longueur donnee POST.
void netCGI_ProcessData (uint8_t code, const char *data, uint32_t len) {
  char var[40];
	uint8_t tab[50];
	char strlcd[5];
	char strled[5];
	char strledcheck[7];
	char str2[5];
	char retlcd=0,retled=0;
	int i;
	
	strcpy(strlcd,"lcd1=");	
	strcpy(strled,"led0=");
	strcpy(strledcheck,"checked");
	

	if (code != 0) {
    // Les autres codes sont ignor�s
    return;
  }
	
  if (len == 0) {
    // Si pas de donn�e � traiter
    return;
  }
		
  do {
    // Appel de la fonction d'analyse de la trame "POST"
    data = netCGI_GetEnvVar (data, var, sizeof (var));	// var contient la donn�e � g�rer
    if (var[0] != 0) {
      // si il y a une donn�e � g�rer
			//METTRE ICI LE TRAITEMENT DE LA CHAINE ENVOYE PAR LE NAVIGATEUR
			retlcd=strncmp(&strlcd[0],&var[0],5); //G�re si c'est bien la trame du LCD
			retled=strncmp(&strled[0],&var[0],5); //G�re si c'est bien la trame de la LED
			
			if (retlcd==0){ 
			strcpy(lcd_text,&var[5]);
		}
			
			if (retled==0){
				P2= var[5];
				//P2 = strncmp(&strledcheck[0],&var[5],7);
				sprintf(lcd_text,"%c",P2);
				GLCD_DrawString         (3, 1, lcd_text);
				if (P2==1) LED_On(0);
				else LED_Off(0);
				
		}
		
			//FIN TRAITEMENT TRAME
			GLCD_DrawString(100,100,lcd_text);	// colonne puis ligne en pixel
			GLCD_DrawString(100,100,lcd_text);	// colonne puis ligne en pixel
    }
  } while (data);			// Tant qu'il a a des donn�es � traiter
	
}
 
// Fonction de g�n�ration des lignes CGI � mettre � jour
// \param[in]     env           environment string.
// \param[out]    buf           output data buffer.
// \return        number of bytes written to output buffer.
uint32_t netCGI_Script (const char *env, char *buf, uint32_t buf_len, uint32_t *pcgi) {
  uint32_t len = 0;

  switch (env[0]) {
    osDelay(1000);
    case 'a':
      // Mise a jour du champ du script CGI
			sprintf(table,"%s",fantome);
      len = sprintf (buf,&env[2],table);
			 break;
		case 'b': 
			len = sprintf(buf,&env[2] ,adv2);
			break;
		case 'c':
			len=sprintf(buf , &env[2] ,"noot" );

				break;
		}
  return (len);

 }

 uint32_t udp_cb_func (int32_t socket, const  NET_ADDR *addr, const uint8_t *buf, uint32_t len) {
	char i,*ptr;
	char str[50]; //Str mange le buf notre chaine de caract�re utile
	int len_str=strlen(str); 	
	char delim[]="#";
		
	*str=*buf; //Miam le caract�re
	ptr=strtok(str,delim);  
	
	while (ptr!=NULL){
		fantome[i]=buf[i];
		i++;
		ptr = strtok(NULL,delim);
	}
/*		
  if (buf[0] != 0x00) {
		for (i=0;i<=len;i++){
		fantome[i]=buf[i];
			
		}
	}*/
  return (0);
}
