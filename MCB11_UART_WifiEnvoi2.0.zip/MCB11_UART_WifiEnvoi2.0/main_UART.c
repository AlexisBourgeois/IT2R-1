/*----------------------------------------------------------------------------
 * Programme Exemple utilisation biblioth�ques UART
 * - Emission : Envoie la trame Id 0x361 de data 1 2 3 4  (1�re data = 0x01), d�lai 1s
 * - Reception : fait un echo sur la liaison s�rie avec +1 (ex : A->B)
 * Attention : enlever les cavaliers ISP et RST pour utiliser la liaison s�rie.
 *---------------------------------------------------------------------------*/

#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions
#include "LPC11xx.h"                    		// Device header
#include "GPIO.h"
#include "UART.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "cmsis_os.h"                                           // CMSIS RTOS header fil
#include "RTE_Components.h"             // Component selection

void Thread_R (void const *argument);                             // thread reception
void Thread_T (void const *argument);                             // thread emission
void Thread_D (void const *argument);     

osMailQId maBAL;
osMailQDef(maBAL, 200, char);

void Init_WiFi(void);
void sendCommand(char * command);
void sendData(char* Msg);

osThreadId tid_Thread_R, tid_Thread_T, tid_Thread_D;                            // thread id
osThreadDef (Thread_R, osPriorityNormal, 1, 0);                   // thread object
osThreadDef (Thread_T, osPriorityNormal, 1, 0);                   // thread object
osThreadDef (Thread_D, osPriorityNormal, 1, 0); 

// Protos initialisation
void Init_LPC11C14(void);
/* Protos fonctions Callback */
void CAN_rx(uint8_t msg_obj_num);
void CAN_tx(uint8_t msg_obj_num);
void CAN_error(uint32_t error_info);


/* Publish CAN Callback Functions */
/*
 * main: initialize and start the system
 */
 

int main (void) {
  osKernelInitialize ();                    // initialize CMSIS-RTOS
  // initialize peripherals here
	
	Init_LPC11C14();
	Init_UART();
	Initialise_GPIO();
	Ecriture_GPIO(0);
	Allumer_1LED(4);
	
	maBAL=osMailCreate(osMailQ(maBAL), NULL);
  // Creation des threads
	tid_Thread_T = osThreadCreate (osThread(Thread_T), NULL);
	tid_Thread_R = osThreadCreate (osThread(Thread_R), NULL);
	tid_Thread_D = osThreadCreate (osThread(Thread_D), NULL);

  osKernelStart ();                         // start thread execution 
	osDelay(osWaitForever);
}

// Thread de reception
void Thread_R (void const *argument) {
		char RxChar,*pChar;
	Allumer_1LED(3);
  while (1) {
		RxChar=UART_Rx();		// A mettre ds boucle pour recevoir 
		osSignalWait(0x01, osWaitForever);	// sommeil attente reception
		
		pChar=osMailAlloc(maBAL, osWaitForever);
		*pChar=RxChar;
		osMailPut (maBAL, pChar);
  }
	
/*	char recu[8];
	
  while (1) {
		//osSignalWait(0x01,osWaitForever);	// on attend l'EVENT RECEP fonction CB
		recu[0]= UART_Rx ();
		UART_Tx(recu[0]+1);

		// Affichage LED
		Ecriture_GPIO(recu[0]);
  }*/
}

// Thread d'emission
void Thread_T (void const *argument) {
	
	Allumer_1LED(2);
	Init_WiFi();
	while(1)
		{
	sendCommand("AT+CIPSTART=\"UDP\",\"192.168.1.100\",2020\r\n");
	osDelay(2000);
   // Send Data to the Server (HyperTerminal test server or ThingSpeak server)
		sendData("a183#b293#c589#d856#f154#e589#\r\n");
	// Close Socket connection
		sendCommand("AT+CIPCLOSE\r\n");
  //  sendCommand("AT+CIPCLOSE\r\n");
	}
	
	
	/*char i = 0;
	char tab[10] = "IT2R";
	Init_WiFi();
  while (1) {
		 //Envoi d'un tableau 0xAA 0xBB 0xCC
		osSignalWait(0x01,osWaitForever);	// on attend l'EVENT RECEP fonction CB
		
		UART_TxString(tab);
		i++;
		Ecriture_GPIO(i);
		
    osDelay (1000);    // tempo 
  }*/
}

void Thread_D (void const *argument) {
	char *pRxChar;
	osEvent RxEv;
	int i=0;	// i pour position colonne caract�re
	char RxBuf[200];
	int Reset=0;
	Allumer_1LED(1);
  while (1) {
		RxEv = osMailGet(maBAL, osWaitForever);
		pRxChar=RxEv.value.p;
		
		RxBuf[i]=*pRxChar;
		i++;
		//Suivant le caract�re r�cup�r�
		switch(*pRxChar)
		{
			case 0x0D: 		//Un retour chariot? On ne le conserve pas...
				i--;
				break;
			case 0x0A:										//Un saut de ligne?
				RxBuf[i-1]=0;											//=> Fin de ligne, donc, on "cloture" la chaine de caract�res
				
			  //Si mode AT+RST, BaudRate par d�faut (74880bits/s): messages illisibles : On les d�tecte pour ne pas les afficher
				if(Reset==1)
				{
					if((strncmp("OK",RxBuf,2)!=0)&&(strncmp("WIFI",RxBuf,4)!=0)&&(strncmp("Ai-Th",RxBuf,5)!=0)&&(strncmp("ready",RxBuf,5)!=0))
						Allumer_1LED(5);
					else
						Eteindre_1LED(5);
				}				
				
				//Fin de la commande AT+RST, on peut donc afficher � nouveau
				if(strncmp("ready",RxBuf,5)==0)
					Reset=0;				
				
				//Indicateur de passage en mode AT+RST
				if(strcmp("AT+RST",RxBuf)==0)
					Reset=1;
				
				//Colorisation de certains types de messages
				if(strncmp("AT+",RxBuf,3)==0)
					Allumer_1LED(0);
				else
				{
					if(strcmp("OK",RxBuf)==0)
						Allumer_1LED(1);
					else
					{
						if((strncmp("FAIL",RxBuf,4)==0)||(strncmp("ERROR",RxBuf,5)==0))
							Allumer_1LED(6);
						else
							Allumer_1LED(7);
					}
				}
				//Gestion d'affichage par pages												//On se remet au d�but du buffer de r�ception pour la prochaine ligne � recevoir

				if((strcmp("OK",RxBuf)==0)||(strcmp("SEND OK",RxBuf)==0))
					osSignalSet(tid_Thread_T, 0x04);
				else
				{
					if(strcmp("ready",RxBuf)==0)
						osSignalSet(tid_Thread_T, 0x06);
				}
				break;
		}
		osMailFree(maBAL, pRxChar);
  }
}
void Init_LPC11C14(void) {
	SystemCoreClockUpdate();

	/* Output the Clk onto the CLKOUT Pin PIO0_1 to monitor the freq on a scope */
	LPC_IOCON->PIO0_1	= (1<<0);
	/* Select the MAIN clock as the clock out selection since it's driving the core */
	LPC_SYSCON->CLKOUTCLKSEL = 3;
	/* Set CLKOUTDIV to 6 */
	LPC_SYSCON->CLKOUTDIV = 10;		//	CLKOUT Divider = 10
	/* Enable CLKOUT */
	LPC_SYSCON->CLKOUTUEN = 0;
	LPC_SYSCON->CLKOUTUEN = 1;
	while (!(LPC_SYSCON->CLKOUTUEN & 0x01));
	
}


void sendCommand(char * command)
{
	UART_TxString(command); // send the read character to the esp8266
		osDelay(100);
	if(strncmp("AT+RST",command,6)==0)
		osSignalWait(0x06, osWaitForever);		// sommeil fin commande RST
	else
		osSignalWait(0x04, osWaitForever);		// sommeil fin autres commande
}


void Init_WiFi(void)
{
	// reset module
		
		sendCommand("AT+RST\r\n");
    // configure as Station 
		sendCommand("AT+CWMODE=1\r\n");
	// disconnect from any previous Access Point
		sendCommand("AT+CWQAP\r\n");
	//Connect to YOUR Access Point
		sendCommand("AT+CWJAP=\"ciscoG5\",\"cachanit2rG5\"\r\n");
	//Display IP parameters
		Allumer_1LED(5);
}

void sendData(char* data)
{
	char Msg[50];
	sprintf(Msg,"AT+CIPSEND=%d\r\n",strlen(data));
	sendCommand(Msg);
	sendCommand(data);
}

