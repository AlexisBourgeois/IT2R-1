/****************************************************************************
 *   Librairie des fonctions UART permettant l'utilisation de la carte d'extension avec MCB11C4 (KEIL)
 *	 IUT de Cachan - 13/12/2018
 *   Project: NXP LPC11xx UART example
 *
****************************************************************************/
#include "LPC11xx.h"
#include "uart.h"


/****************************************************************************
 *   Fonction initialisation UART
 *	 8 bits, sans Parit�, 1 Stop bit - 115200 bauds
 *		
****************************************************************************/
void Init_UART(void) {
	
	LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 16) ;
	LPC_IOCON->PIO1_6 &= ~0x07;    /*  UART I/O config */
  LPC_IOCON->PIO1_6 |= 0x01;     /* UART RXD */
  LPC_IOCON->PIO1_7 &= ~0x07;	
  LPC_IOCON->PIO1_7 |= 0x01;     /* UART TXD */

  /* Enable UART clock */
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<12);
  LPC_SYSCON->UARTCLKDIV = 0x1;     /* divided by 1 */

  LPC_UART->LCR = 0x83;             /* 8 bits, no Parity, 1 Stop bit */
	
	// Debit
	LPC_UART->DLM = 0;							
  LPC_UART->DLL = 192;//16=115200 bauds et 192=9600 bauds
	LPC_UART->FDR = 0x05 | (0x08<<4);		/* Default */
	
	LPC_UART->LCR = 0x03;		/* DLAB = 0 */
}

/****************************************************************************
 *   Fonction Tx pour 1 octet
 * 
****************************************************************************/
void UART_Tx (char val) {
	
	while((LPC_UART-> LSR & 0x20) != 0x20);
	LPC_UART->THR = val;
}

/****************************************************************************
 *   Fonction Rx pour 1 octet
 * 
****************************************************************************/
char UART_Rx (void) {
	
	while((LPC_UART-> LSR & 0x01) != 0x01);
	return LPC_UART->RBR;	
}

/****************************************************************************
 *   Fonction Tx pour chaine de caract�res
 * 
****************************************************************************/
void UART_TxString(char *pMsg) {

	int i;
	for (i=0;*(pMsg+i) != '\0';i++) 
		{
			UART_Tx(*(pMsg+i));
		}
}

/******************************************************************************
**                            End Of File
******************************************************************************/
