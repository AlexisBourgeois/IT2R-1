/*----------------------------------------------------------------------------
 * Programme Exemple utilisation biblioth�ques CAN OnChip
 * Carte 2 : 
 * - Attend la trame Id 0x0C8 et affiche en LED la premi�re data
 * - Envoie la trame Id 0x361 de data 1 2 3 4  (1�re data = 0x01), d�lai 1s
 * Attention : Bien v�rifier que la zone RAM autoris�e commence � 0x100000C0 (voir Options for Target)
 *---------------------------------------------------------------------------*/

#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions
#include "LPC11xx.h"                    		// Device header
#include "GPIO.h"

#include "cmsis_os.h"                                           // CMSIS RTOS header file

#include "rom_drivers.h"

#ifndef NULL
#define NULL    ((void *)0)
#endif

// Pointeur sur la ROM contenant les fonctions CAN
ROM **rom = (ROM **)0x1fff1ff8;

// Objets CAN de reception et emission
CAN_MSG_OBJ msg_objR, msg_objT;	

void Thread_R (void const *argument);                             // thread reception
void Thread_T (void const *argument);                             // thread emission

osThreadId tid_Thread_R, tid_Thread_T;                            // thread id
osThreadDef (Thread_R, osPriorityNormal, 1, 0);                   // thread object
osThreadDef (Thread_T, osPriorityNormal, 1, 0);                   // thread object

// Protos Initialisation
void Init_CAN(void);
void Init_LPC11C14(void);

/* Protos fonctions Callback */
void CAN_rx(uint8_t msg_obj_num);
void CAN_tx(uint8_t msg_obj_num);
void CAN_error(uint32_t error_info);

/* Publish CAN Callback Functions */
CAN_CALLBACKS callbacks = {
   CAN_rx,
   CAN_tx,
   CAN_error,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL,
};


/*
 * main: initialize and start the system
 */
int main (void) {
  osKernelInitialize ();                    // initialize CMSIS-RTOS

  // initialize peripherals here
	Init_LPC11C14();
	Init_CAN();
	
	Initialise_GPIO();
	Ecriture_GPIO(0);
	
  // Creation des threads
	tid_Thread_R = osThreadCreate (osThread(Thread_R), NULL);
	tid_Thread_T = osThreadCreate (osThread(Thread_T), NULL);

  osKernelStart ();                         // start thread execution 
}

// Thread de reception
void Thread_R (void const *argument) {

	char recu[8];
	int id, taille,i;
	Allumer_1LED(1);
  while (1) {
		osSignalWait(0x01,osWaitForever);	// on attend l'EVENT RECEP fonction CB

		/* On recupere l'objet CAN recu */
		(*rom)->pCAND->can_receive(&msg_objR);

    /* On traite la trame recue */
    id = msg_objR.mode_id ;
		taille = msg_objR.dlc;
		for (i=0;i<taille;i++) recu[i] = msg_objR.data[i];
		for (i=taille;i<8;i++) recu[i] = 0x00;
		
		// Affichage LED
		Ecriture_GPIO(recu[0]);
  }
}

// Thread d'emission
void Thread_T (void const *argument) {

	char i = 0;
	Allumer_1LED(4);
  while (1) {
		/* Envoi d'une trame CAN Id 0x361 sur objet 0 */
		msg_objT.msgobj  = 0;
		msg_objT.mode_id = 0x361;
		msg_objT.mask    = 0x0;
		msg_objT.dlc     = 4;			// 4 data a envoyer
		msg_objT.data[0] = 0x01;	
		msg_objT.data[1] = 0x02;	
		msg_objT.data[2] = 0x03;	
		msg_objT.data[3] = 0x04;	
		
		// envoi de la trame
    (*rom)->pCAND->can_transmit(&msg_objT);
		
		osSignalWait(0x01, osWaitForever);		// sommeil en attente fin emission sur Event CB
		
		i++;
		Ecriture_GPIO(i);
		
    osDelay (1000);    // on envoie toutes les secondes 
  }
}


void Init_LPC11C14(void) {
	SystemCoreClockUpdate();

	/* Output the Clk onto the CLKOUT Pin PIO0_1 to monitor the freq on a scope */
	LPC_IOCON->PIO0_1	= (1<<0);
	/* Select the MAIN clock as the clock out selection since it's driving the core */
	LPC_SYSCON->CLKOUTCLKSEL = 3;
	/* Set CLKOUTDIV to 6 */
	LPC_SYSCON->CLKOUTDIV = 10;		//	CLKOUT Divider = 10
	/* Enable CLKOUT */
	LPC_SYSCON->CLKOUTUEN = 0;
	LPC_SYSCON->CLKOUTUEN = 1;
	while (!(LPC_SYSCON->CLKOUTUEN & 0x01));
	
}

void Init_CAN(void) {
	
	uint32_t ClkInitTable[2] = {
  0x00000000UL, // CANCLKDIV		//
  0x00001C57UL  // CAN_BTR			// -> 125 kHz
	};
	
	/* Initialisation du controlleur CAN */
	(*rom)->pCAND->init_can(&ClkInitTable[0], 1);

	/* Configuration des fonctions CB pour CAN */
	(*rom)->pCAND->config_calb(&callbacks);

	/* Enable IRQ CAN */
	NVIC_EnableIRQ(CAN_IRQn);
	
	/* Object 1 pour reception des Id 11 bits 0x0c8 */
	msg_objR.msgobj = 1;
	msg_objR.mode_id = 0x0C8;
	msg_objR.mask = 0x7FF;
	(*rom)->pCAND->config_rxmsgobj(&msg_objR);	
}

/*	CAN receive callback */
/*	Function is executed by the Callback handler after
	a CAN message has been received */
void CAN_rx(uint8_t msg_obj_num){
  osSignalSet(tid_Thread_R, 0x01);	// on reveille la tache en attente de reception
  return;
}

/*	CAN transmit callback */
/*	Function is executed by the Callback handler after
	a CAN message has been transmitted */
void CAN_tx(uint8_t msg_obj_num){
	osSignalSet(tid_Thread_T, 0x01);	// on reveille la tache d'envoi en attente fin envoi
  return;
}

/*	CAN error callback */
/*	Function is executed by the Callback handler after
	an error has occured on the CAN bus */
void CAN_error(uint32_t error_info){
  return;
}

/*	CAN interrupt handler */
/*	The CAN interrupt handler must be provided by the user application.
	It's function is to call the isr() API located in the ROM */
void CAN_IRQHandler (void){
  (*rom)->pCAND->isr();
}
