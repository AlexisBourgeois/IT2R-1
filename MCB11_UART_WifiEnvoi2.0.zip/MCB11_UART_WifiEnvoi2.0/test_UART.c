#include "LPC17xx.h"
// Définition des registres du microcontrôleur
int main(void)
{
int i;
LPC_PINCON->PINSEL4 = 0x0A; // Broche P2.0 pour TX et P2.1 pour RX
LPC_UART1->LCR = 0x03; // 8 bits, sans parité, 1 bit de stop
// Réglage de la vitesse de transmission
LPC_UART1->LCR |= 0x80;
// Forçage bit DLAB=1 (Demande autorisation de modification)
LPC_UART1->DLM = 0;
// Pas de sur-division de PCLK
LPC_UART1->DLL = 9;
// Division principale par 9 de PCLK
LPC_UART1->FDR = 0x21;
// Division fractionnaire par 1,5 (DIVADDVAL=1 et MULVAL=2)
LPC_UART1->LCR &= 0x7F;
// Forçage bit DLAB=0 (Fin d'autorisation de modification)
while(1)
{
LPC_UART1->THR = 0x75;
for(i=0;i<5000;i++);
}
// Envoi de la donnée (valeur 0x75)
// Laisser un peu de temps avant un autre envoi
re
